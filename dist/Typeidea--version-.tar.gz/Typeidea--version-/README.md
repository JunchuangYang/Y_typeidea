# Y_typeidea
基于《Django企业开发实战》图书自学，练习仓库。
